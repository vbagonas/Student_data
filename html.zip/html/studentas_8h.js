var studentas_8h =
[
    [ "Zmogus", "class_zmogus.html", "class_zmogus" ],
    [ "Studentas", "class_studentas.html", "class_studentas" ],
    [ "atsitiktinaspaz", "studentas_8h.html#aeb5a73683e41712556c3104c992b6050", null ],
    [ "bal_med_lyg", "studentas_8h.html#af3633680f91327d6af8930ef44952a70", null ],
    [ "bal_vid_lyg", "studentas_8h.html#a1c91213c2b93c45e627b89bf7eae7a27", null ],
    [ "duomenu_ivedimas", "studentas_8h.html#a8ee0988aff8bf84e4c4de1aa6ae008e6", null ],
    [ "file_gen", "studentas_8h.html#a3658dc3e754022c10812979344e10eb6", null ],
    [ "isvedimas_i_faila", "studentas_8h.html#a22c848802db30b8741b7ea336641bc9e", null ],
    [ "ivesk_skaiciu", "studentas_8h.html#aab080f5958440074a88176840d9e6343", null ],
    [ "pavardlyg", "studentas_8h.html#adc756da3e39435c67b5c65479a6e57ff", null ],
    [ "Rusiavimas2", "studentas_8h.html#abaadae937d5a96a1e585064aa3cfa42e", null ],
    [ "Rusiuoti", "studentas_8h.html#a2ab653105a947209f43bc445cb312aa5", null ],
    [ "Skaityti", "studentas_8h.html#a821c2d9eee03e7d73bd160d148dc2d92", null ],
    [ "vardlyg", "studentas_8h.html#a99d7e94a545eb3f318e85253817afbd1", null ],
    [ "VidurkisIrMediana", "studentas_8h.html#a82aa29ec7e3e94294007ea80ef6ec6c7", null ]
];