var files_dup =
[
    [ "functions.cpp", "functions_8cpp.html", "functions_8cpp" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "studentas.h", "studentas_8h.html", "studentas_8h" ]
];