var class_zmogus =
[
    [ "abstrakti", "class_zmogus.html#a1683146f6583a373c4ce407370cfd09f", null ],
    [ "setPav", "class_zmogus.html#a9929cb57ca2b615ef7ace882903c9a35", null ],
    [ "setVard", "class_zmogus.html#a442ae7745819d3622c7857b833d83a4f", null ],
    [ "pavarde_", "class_zmogus.html#a95b83ef4d9bbe9b88d78c17563bafa5a", null ],
    [ "vardas_", "class_zmogus.html#a09b290c9be6039ce3a94e1557def9b3a", null ]
];