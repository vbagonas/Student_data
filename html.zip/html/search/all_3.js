var searchData=
[
  ['duomenu_5fivedimas_0',['duomenu_ivedimas',['../functions_8cpp.html#a8ee0988aff8bf84e4c4de1aa6ae008e6',1,'duomenu_ivedimas(Studentas &amp;stud, int i, int &amp;n, int &amp;sum, int m):&#160;functions.cpp'],['../studentas_8h.html#a8ee0988aff8bf84e4c4de1aa6ae008e6',1,'duomenu_ivedimas(Studentas &amp;stud, int i, int &amp;n, int &amp;sum, int m):&#160;functions.cpp']]]
];
