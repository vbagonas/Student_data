var searchData=
[
  ['isvedimas_5fi_5ffaila_0',['isvedimas_i_faila',['../functions_8cpp.html#a22c848802db30b8741b7ea336641bc9e',1,'isvedimas_i_faila(vector&lt; Studentas &gt; studentai, string pavadinimas):&#160;functions.cpp'],['../studentas_8h.html#a22c848802db30b8741b7ea336641bc9e',1,'isvedimas_i_faila(vector&lt; Studentas &gt; studentai, string pavadinimas):&#160;functions.cpp']]],
  ['ivesk_5fskaiciu_1',['ivesk_skaiciu',['../functions_8cpp.html#aab080f5958440074a88176840d9e6343',1,'ivesk_skaiciu(int x1, int x2):&#160;functions.cpp'],['../studentas_8h.html#aab080f5958440074a88176840d9e6343',1,'ivesk_skaiciu(int x1, int x2):&#160;functions.cpp']]]
];
