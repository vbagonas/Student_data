var searchData=
[
  ['pavarde_5f_0',['pavarde_',['../class_zmogus.html#a95b83ef4d9bbe9b88d78c17563bafa5a',1,'Zmogus']]],
  ['pavardlyg_1',['pavardlyg',['../functions_8cpp.html#adc756da3e39435c67b5c65479a6e57ff',1,'pavardlyg(const Studentas &amp;a, const Studentas &amp;b):&#160;functions.cpp'],['../studentas_8h.html#adc756da3e39435c67b5c65479a6e57ff',1,'pavardlyg(const Studentas &amp;a, const Studentas &amp;b):&#160;functions.cpp']]]
];
