var searchData=
[
  ['setbalasmed_0',['setBalasMed',['../class_studentas.html#a69e2bce8f2d1bcf1eed7e182ac1c1555',1,'Studentas']]],
  ['setbalasvid_1',['setBalasVid',['../class_studentas.html#a3ae16c409eb4bfd3bba81a40f464f325',1,'Studentas']]],
  ['setegzam_2',['setEgzam',['../class_studentas.html#a436e3260b2745199e139386bedfa97c6',1,'Studentas']]],
  ['setmediana_3',['setMediana',['../class_studentas.html#a62ce57d471f61478ba4e1b564a118b2c',1,'Studentas']]],
  ['setpav_4',['setPav',['../class_zmogus.html#a9929cb57ca2b615ef7ace882903c9a35',1,'Zmogus']]],
  ['setpavarde_5',['setPavarde',['../class_studentas.html#a33f351b1ef09f33cc1d5d54ce36524f1',1,'Studentas']]],
  ['setpazym_6',['setPazym',['../class_studentas.html#a3d19d672b6a5793fd7ec93053cc57d71',1,'Studentas']]],
  ['setvard_7',['setVard',['../class_zmogus.html#a442ae7745819d3622c7857b833d83a4f',1,'Zmogus']]],
  ['setvardas_8',['setVardas',['../class_studentas.html#ac78bbac0ceb23b47b7c11eee40d95069',1,'Studentas']]],
  ['setvidurkis_9',['setVidurkis',['../class_studentas.html#a9be53bf25b6ac56674bd6992576b3faa',1,'Studentas']]],
  ['skaityti_10',['Skaityti',['../functions_8cpp.html#a821c2d9eee03e7d73bd160d148dc2d92',1,'Skaityti(vector&lt; Studentas &gt; &amp;studentai, int &amp;m, string failas):&#160;functions.cpp'],['../studentas_8h.html#a821c2d9eee03e7d73bd160d148dc2d92',1,'Skaityti(vector&lt; Studentas &gt; &amp;studentai, int &amp;m, string failas):&#160;functions.cpp']]],
  ['studentas_11',['Studentas',['../class_studentas.html',1,'Studentas'],['../class_studentas.html#ab459e995e8c9b24cdc9aec5b09a66539',1,'Studentas::Studentas()'],['../class_studentas.html#ad03f446a7aa2dd8c2b20179be349f168',1,'Studentas::Studentas(const Studentas &amp;o)']]],
  ['studentas_2eh_12',['studentas.h',['../studentas_8h.html',1,'']]]
];
