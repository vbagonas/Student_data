var searchData=
[
  ['abstrakti_0',['abstrakti',['../class_zmogus.html#a1683146f6583a373c4ce407370cfd09f',1,'Zmogus::abstrakti()'],['../class_studentas.html#a719b7c703418ce33f876fdaba796ac4d',1,'Studentas::abstrakti()']]],
  ['atsitiktinaspaz_1',['atsitiktinaspaz',['../functions_8cpp.html#aeb5a73683e41712556c3104c992b6050',1,'atsitiktinaspaz(int min, int max):&#160;functions.cpp'],['../studentas_8h.html#aeb5a73683e41712556c3104c992b6050',1,'atsitiktinaspaz(int min, int max):&#160;functions.cpp']]]
];
