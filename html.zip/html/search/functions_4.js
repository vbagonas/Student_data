var searchData=
[
  ['file_5fgen_0',['file_gen',['../functions_8cpp.html#a3658dc3e754022c10812979344e10eb6',1,'file_gen(int &amp;m, int &amp;n):&#160;functions.cpp'],['../studentas_8h.html#a3658dc3e754022c10812979344e10eb6',1,'file_gen(int &amp;m, int &amp;n):&#160;functions.cpp']]]
];
