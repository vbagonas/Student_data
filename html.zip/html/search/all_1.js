var searchData=
[
  ['bal_5fmed_5flyg_0',['bal_med_lyg',['../functions_8cpp.html#af3633680f91327d6af8930ef44952a70',1,'bal_med_lyg(const Studentas &amp;a, const Studentas &amp;b):&#160;functions.cpp'],['../studentas_8h.html#af3633680f91327d6af8930ef44952a70',1,'bal_med_lyg(const Studentas &amp;a, const Studentas &amp;b):&#160;functions.cpp']]],
  ['bal_5fvid_5flyg_1',['bal_vid_lyg',['../functions_8cpp.html#a1c91213c2b93c45e627b89bf7eae7a27',1,'bal_vid_lyg(const Studentas &amp;a, const Studentas &amp;b):&#160;functions.cpp'],['../studentas_8h.html#a1c91213c2b93c45e627b89bf7eae7a27',1,'bal_vid_lyg(const Studentas &amp;a, const Studentas &amp;b):&#160;functions.cpp']]]
];
