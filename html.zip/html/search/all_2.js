var searchData=
[
  ['clearpaz_0',['clearPaz',['../class_studentas.html#ae98b59414bf0e1f15ecd75c9ee747a8d',1,'Studentas']]]
];
