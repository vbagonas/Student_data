var searchData=
[
  ['vardas_5f_0',['vardas_',['../class_zmogus.html#a09b290c9be6039ce3a94e1557def9b3a',1,'Zmogus']]],
  ['vardlyg_1',['vardlyg',['../functions_8cpp.html#a99d7e94a545eb3f318e85253817afbd1',1,'vardlyg(const Studentas &amp;a, const Studentas &amp;b):&#160;functions.cpp'],['../studentas_8h.html#a99d7e94a545eb3f318e85253817afbd1',1,'vardlyg(const Studentas &amp;a, const Studentas &amp;b):&#160;functions.cpp']]],
  ['vidurkisirmediana_2',['VidurkisIrMediana',['../functions_8cpp.html#a82aa29ec7e3e94294007ea80ef6ec6c7',1,'VidurkisIrMediana(Studentas &amp;stud, int &amp;n, int &amp;sum, vector&lt; Studentas &gt; &amp;studentai):&#160;functions.cpp'],['../studentas_8h.html#a82aa29ec7e3e94294007ea80ef6ec6c7',1,'VidurkisIrMediana(Studentas &amp;stud, int &amp;n, int &amp;sum, vector&lt; Studentas &gt; &amp;studentai):&#160;functions.cpp']]]
];
